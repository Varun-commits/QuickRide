package book_a_ride;

import java.net.URL;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.remote.DesiredCapabilities;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileBy;
import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidDriver;


public class quickRideBooking {
	
	static AppiumDriver<MobileElement> driver;
	AndroidDriver<MobileElement> drivers;

	public static void main(String[] args) {
		
		try {
			openOlaApp();
			
		} catch (Exception exp) {
		
			exp.getCause();
			exp.getMessage();
			exp.printStackTrace();
		}

	}
	
	public static void openOlaApp() throws Exception {
		
		DesiredCapabilities cap = new DesiredCapabilities();
		
		cap.setCapability("deviceName", "HONOR View20");
		cap.setCapability("udid", "UUQDU19124000108");
		cap.setCapability("platformName", "Android");
		cap.setCapability("platformVersion", "9");
		cap.setCapability("app", "C:\\Users\\Varun.rv\\Desktop\\QucikRideApp.apk");
		
        URL url = new URL("http://127.0.0.1:4723/wd/hub");
     	
		driver = new AppiumDriver<MobileElement>(url, cap);
		
		System.out.println("Quick Ride Apllication started");	
		
		allowPermissions();
		verifyOtp();
		bookCab();
		
	}
	
	public static void allowPermissions() {
		
		driver.findElement(MobileBy.id("com.android.packageinstaller:id/permission_allow_button")).click();
	    driver.findElement(MobileBy.id("com.android.packageinstaller:id/permission_allow_button")).click();
		driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
		
	}
	
	public static void verifyOtp() {
		
		driver.findElement(By.id("com.disha.quickride:id/tv_mobile_num_edit_text")).sendKeys("9902609192");
		driver.findElement(By.id("com.disha.quickride:id/next_button")).click();
		driver.findElement(By.id("com.disha.quickride:id/otp_text_1")).sendKeys("0223");	
		
	}
	
	public static void bookCab() {
		
		driver.findElement(By.id("com.disha.quickride:id/iv_from_location")).sendKeys("J.P.nagar,Bengaluru,karnataka,560078");
		driver.findElement(By.id("com.disha.quickride:id/iv_to_location")).click();
		driver.findElement(By.id("com.disha.quickride:id/searchForLocation")).sendKeys("Jayanagar,Bengaluru,karnataka,560011");
		driver.findElement(By.id("com.disha.quickride:id/selectedLocationDescription")).click();
		driver.findElement(By.id("com.disha.quickride:id/btn_ride_create")).click();	
		
	}
	
	
	

}
